def arithmetic_operations(X, Y):
    print(f"{X} + {Y} = {X + Y}")
    print(f"{X} - {Y} = {X - Y}")
    print(f"{X} * {Y} = {X * Y}")
    if Y != 0:
        print(f"{X} / {Y} = {X / Y}")
    else:
        print(f"{X} / {Y} = 除數不能為零")

# 示例使用
try:
    X = float(input("輸入第一個數X："))
    Y = float(input("輸入第二個數Y："))
    arithmetic_operations(X, Y)
except ValueError:
    print("請輸入有效的數字")
