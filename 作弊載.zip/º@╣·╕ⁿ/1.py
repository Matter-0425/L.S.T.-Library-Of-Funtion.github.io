def sum_of_integers(N):
    return N * (N + 1) // 2

# 示例使用
N = int(input("輸入整數N："))
print(f"1 + 2 + 3 + ... + {N} = {sum_of_integers(N)}")
