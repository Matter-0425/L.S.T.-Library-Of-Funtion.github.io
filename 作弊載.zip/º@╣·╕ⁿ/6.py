def find_last_term(N):
    if N <= 1:
        raise ValueError("N 必須大於 1")
    
    total = 0
    i = 0
    while total + i + 1 < N:
        i += 1
        total += i
    
    return i

# 示例使用
N = int(input("輸入整數N："))
print(f"1 + 2 + 3 + ... < {N} 的最後一項是 {find_last_term(N)}")
